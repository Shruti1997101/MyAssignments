import java.util.Scanner;

import robotopn.updateVersion;

//In this assignment tried to use the packages and interfaces.

public class RobotOperations {
    public static void main(String args[]) {

    	int operationChoice = 0;
    	System.out.println("******************Menu****************");
		do
		{
            System.out.println("1.Check the Version");
            System.out.println("2.Mopping");
            System.out.println("3.Cleaning");
            System.out.println("4.Sweeping");
            System.out.println("5.Vacuuming");
            System.out.println("6.Exit");
	    	System.out.println("Choose the Operation you want to Perform Today\t");
	    	Scanner sc = new Scanner(System.in);
	    	operationChoice = sc.nextInt();
	    	updateVersion v1 = new updateVersion();
	    	switch(operationChoice) {
	    	case 1:
	    		v1.UpdateVersion();
	    	case 2: 
	    		v1.mopping();
	    		int innerChoice2 =0;
	    		do {
	    		System.out.println("Would you like to choose the Mode of Operation");
	    		System.out.println("1. Dry Mopping");
	    		System.out.println("2. Wet Mopping");
	    		innerChoice2 = sc.nextInt();
	    		switch(innerChoice2) {
	    		case 1:
	    			MoppingModes c1 = new MoppingOptions();
	    			c1.dryMopping();
	    			break;
	    		case 2: 
	    			MoppingModes c2 = new MoppingOptions();
	    			c2.wetMopping();
	    			break;
	    			
	    		case 3:
	    			System.out.println("Exit....");
	    		}
	    		}while(innerChoice2!=3);
	    		break;
	    	case 3:
	    		v1.Cleaning();
	    		int innerChoice =0;
	    		do {
	    		System.out.println("Would you like to choose the Mode of Operation");
	    		System.out.println("1. Auto Cleaning");
	    		System.out.println("2. Spot Cleaning");
	    		innerChoice = sc.nextInt();
	    		switch(innerChoice) {
	    		case 1:
	    			CleaningMode c1 = new CleaningOptions();
	    			c1.autoCleaning();
	    			break;
	    		case 2: 
	    			CleaningMode c2 = new CleaningOptions();
	    			c2.spotCleaning();
	    			break;
	    		case 3:
	    			System.out.println("Exit....");
	    			
	    		}
	    		}while(innerChoice!=3);
	    		break;
	    	case 4: 
	    		v1.sweeping();
	    		break;
	    	case 5: 
	    		v1.vacuuming();
	    		break;
	    	case 6: System.out.println("Existing....");
	    	}
		}
		while(operationChoice!=6);
		
     }
}

abstract class CleaningMode {
	abstract void autoCleaning();
	abstract void spotCleaning();

}

class CleaningOptions extends CleaningMode {
	void clean() {
		System.out.println("Cleaning is in progress.......");
	}
	void autoCleaning() {
		System.out.println("Auto Cleaning mode is selected...cleaning in Auto Mode");
	}
	void spotCleaning() {
		System.out.println("Spot Cleaning mode is Selected....cleaning in Spot Mode");
	}
}

abstract class MoppingModes {
	abstract void wetMopping(); 
    abstract void dryMopping();
}

class MoppingOptions extends MoppingModes {
	void mopping()
	{
		System.out.println("Mopping in progress........");
	}

	@Override
	void wetMopping() {
		// TODO Auto-generated method stub
		System.out.println("WetMopping Mode is On");	
	}

	@Override
	void dryMopping() {
		// TODO Auto-generated method stub
		System.out.println("DryMopping Mode is On");
	}
}