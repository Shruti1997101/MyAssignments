package robotopn;

public class updateVersion {

	public  void UpdateVersion() {
		 String defaultVersion = "1.0.0";
     System.out.println("\nCurrent Version is:\n"+defaultVersion);
}
	public void sweeping() {
		System.out.println("Sweeoing in progress....");
	}
	
	public void mopping() {
		System.out.println("Mopping in progress....");
	}
	
	public void vacuuming() {
		System.out.println("Vacuuming in progress.....");
	}
	
	public void Cleaning() {
		System.out.println("Cleaning in progress.....");
	}
}
