import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AssociationTest {

	public static void main(String[] args) throws InvalidAmoutException {
     System.out.println("---------------Main-------------\n");

     CarLoan L1 = new CarLoan();
     L1.ActualLoanAmount(100000);
     int simpleint =  L1.calculateROI(100000, 9 , 5);
     System.out.println("\nThe Simple Interest on Amount is\t"+simpleint);

     CarLoan L2 = new CarLoan();
     L2.ActualLoanAmount(000000);
     L2.calculateROI(00000, 9, 5);

     //Collection Framework
     ArrayList<YearlyROI> ROIChart = new ArrayList<>();  //HashSet can be used 

     YearlyROI R1 = new YearlyROI(2012,"SBI",10);
     YearlyROI R2 = new YearlyROI(2014,"Bank of Baroda",10.11f);
     YearlyROI R3 = new YearlyROI(2012,"Bank Of India",8.89f);

     ROIChart.add(R1);
     ROIChart.add(R2);
     ROIChart.add(R3);

     System.out.println("\n***********ROI Comparison Chart(Based On Year)**********\n");
     
     Comparator<YearlyROI> cmp = new YearComparator();
     Collections.sort(ROIChart, cmp);
     for(YearlyROI theROI : ROIChart ) { // no iterator required
			System.out.println("\nROI : "+theROI);
		}
	}
}

class Loan{

}

class SROI {
//uses of 
}


//comparator and comparable implementation
class YearComparator implements Comparator<YearlyROI> {
	public int compare(YearlyROI x, YearlyROI y) {
		System.out.println("YearComparator : comparing "+x.getYear()+" with "+y.getYear());
		return Integer.compare(x.getYear(), y.getYear());
	}
}

class YearlyROI implements Comparable<YearlyROI>{

	private int year;
	private String BankName;
	private float ROI;

	@Override
	public int compareTo(YearlyROI o) {
		System.out.println("Comparable : comparing "+o.year+" with "+year);
		return Integer.compare(o.year, year);
	}
	
	public YearlyROI(int year, String BankName, float ROI) {
		this.ROI = ROI;
		this.year = year;
		this.BankName = BankName;
	}

	public String getBankName() {
		return BankName;
	}

	public void setBankName(String BankName) {
		this.BankName = BankName;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public void setROI(float ROI) {
        this.ROI = ROI;		
	}

	public float getROI() {
		return ROI;
	}
	
	@Override
	public String toString() {
		return "BankDetails  [BankName=" + BankName + ", ROI=" + ROI + ", year=" + year + "]";
	}

}

@SuppressWarnings("serial")
class InvalidAmoutException extends Exception {

	  public InvalidAmoutException(String message){
	     super(message);
	  }
}

class CarLoan extends Loan {
	int ActualLoanAmount(int Amount) {
		System.out.println("\nSanction Amount is\t"+Amount);
		return Amount;
	}
	 int calculateROI(int pAmt, int rOI, int Time ) throws InvalidAmoutException {
	    int SI = 0;
       try {
    	   if(pAmt == 0) {
    		   pAmt = 0;
    		   throw new InvalidAmoutException("Amount is Invalid");
    	   }
    	   	} catch(InvalidAmoutException e) {
    	   		System.out.println(e);
    	   		SI = (pAmt*rOI*Time)/100;	
    	   		// catch the principal amount
    	   	}
       return SI ;
	}
}