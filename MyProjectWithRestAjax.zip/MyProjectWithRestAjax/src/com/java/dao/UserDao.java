package com.java.dao;

public class UserDao {

}
