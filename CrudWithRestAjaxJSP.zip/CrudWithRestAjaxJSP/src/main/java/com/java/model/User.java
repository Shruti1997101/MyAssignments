package com.java.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="User")
public class User {
	
	private String Bookid;
	private String Bookname;
	private int shelfNumber;
	
	public String getBookId() {
		return Bookid;
	}
	
	@XmlElement
	public void setBookId(String Bookid) {
		this.Bookid = Bookid;
	}
	public String getBookName() {
		return Bookname;
	}
	
	@XmlElement
	public void setBookName(String Bookname) {
		this.Bookname = Bookname;
	}
	public int getSheflNumber() {
		return shelfNumber;
	}
	
	@XmlElement
	public void setShelfNumber(int shelfNumber) {
		this.shelfNumber = shelfNumber;
	}
}
